function doPost(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var data = JSON.parse(e.postData.contents);
    var action = data.action || "";

    if (action === "sendAdminOtp") {
      var targetEmail = data.email || "tanvirunivogue@gmail.com";
      var otp = data.otp || "";
      MailApp.sendEmail({
        to: targetEmail,
        subject: "আমার খামার — ওনার পিন রিসেট OTP কোড",
        body: "আপনার ওনার পিন রিসেটের জন্য ৬ সংখ্যার OTP কোড: " + otp + "\n\nএই কোডটি অ্যাপে লিখে নতুন পিন সেট করুন।"
      });
      return jsonResponse({ status: "ok", message: "OTP sent" });
    }

    if (action === "updateAdminPin") {
      var sh = getOrCreateSheet(ss, "Settings", ["Key", "Value", "UpdatedAt"]);
      sh.appendRow(["ownerEmail", data.email || "tanvirunivogue@gmail.com", data.updatedAt || new Date().toISOString()]);
      return jsonResponse({ status: "ok", message: "Pin updated log saved" });
    }

    if (action === "addAnimal" && data.animal) {
      var a = data.animal;
      var shA = getOrCreateSheet(ss, "Animals", ["ID", "Tag", "Type", "Breed", "Gender", "Age", "Weight_Kg", "Price_BDT", "Status"]);
      shA.appendRow([a.id, a.tag, a.type, a.breed, a.gender, a.age, a.weight, a.price, a.status]);
      return jsonResponse({ status: "ok" });
    }

    if (action === "addBreeding" && data.breeding) {
      var b = data.breeding;
      var shB = getOrCreateSheet(ss, "Breeding", ["ID", "AnimalTag", "MatingDate", "DueDate", "Stage", "CalfInfo"]);
      shB.appendRow([b.id, b.animalTag, b.matingDate, b.dueDate, b.stage, b.calfInfo]);
      return jsonResponse({ status: "ok" });
    }

    if (action === "addWeight" && data.weight) {
      var w = data.weight;
      var shW = getOrCreateSheet(ss, "WeightLogs", ["ID", "Date", "AnimalTag", "Weight_Kg"]);
      shW.appendRow([w.id, w.date, w.animalTag, w.kg]);
      return jsonResponse({ status: "ok" });
    }

    if (action === "addHealth" && data.health) {
      var h = data.health;
      var shH = getOrCreateSheet(ss, "HealthLogs", ["ID", "Date", "AnimalTag", "Type", "Note", "Cost_BDT", "NextDate"]);
      shH.appendRow([h.id, h.date, h.animalTag, h.type, h.note, h.cost, h.nextDate]);
      return jsonResponse({ status: "ok" });
    }

    if (action === "addProduction" && data.production) {
      var p = data.production;
      var shP = getOrCreateSheet(ss, "ProductionLogs", ["ID", "Date", "AnimalTag", "Milk_Liters", "MilkIncome_BDT", "FeedCost_BDT", "FeedNote"]);
      shP.appendRow([p.id, p.date, p.animalTag, p.milk, p.milkIncome, p.feedCost, p.feedNote]);
      return jsonResponse({ status: "ok" });
    }

    if (action === "addFinance" && data.finance) {
      var f = data.finance;
      var shF = getOrCreateSheet(ss, "FinanceLogs", ["ID", "Date", "Type", "Category", "Amount_BDT"]);
      shF.appendRow([f.id, f.date, f.type, f.category, f.amount]);
      return jsonResponse({ status: "ok" });
    }

    if (action === "fullSync") {
      if (Array.isArray(data.animals)) {
        var shA2 = getOrCreateSheet(ss, "Animals", ["ID", "Tag", "Type", "Breed", "Gender", "Age", "Weight_Kg", "Price_BDT", "Status"]);
        clearDataKeepHeader(shA2);
        data.animals.forEach(function(a) {
          shA2.appendRow([a.id, a.tag, a.type, a.breed, a.gender, a.age, a.weight, a.price, a.status]);
        });
      }
      if (Array.isArray(data.breedingLogs)) {
        var shB2 = getOrCreateSheet(ss, "Breeding", ["ID", "AnimalTag", "MatingDate", "DueDate", "Stage", "CalfInfo"]);
        clearDataKeepHeader(shB2);
        data.breedingLogs.forEach(function(b) {
          shB2.appendRow([b.id, b.animalTag, b.matingDate, b.dueDate, b.stage, b.calfInfo]);
        });
      }
      if (Array.isArray(data.weightLogs)) {
        var shW2 = getOrCreateSheet(ss, "WeightLogs", ["ID", "Date", "AnimalTag", "Weight_Kg"]);
        clearDataKeepHeader(shW2);
        data.weightLogs.forEach(function(w) {
          shW2.appendRow([w.id, w.date, w.animalTag, w.kg]);
        });
      }
      if (Array.isArray(data.healthLogs)) {
        var shH2 = getOrCreateSheet(ss, "HealthLogs", ["ID", "Date", "AnimalTag", "Type", "Note", "Cost_BDT", "NextDate"]);
        clearDataKeepHeader(shH2);
        data.healthLogs.forEach(function(h) {
          shH2.appendRow([h.id, h.date, h.animalTag, h.type, h.note, h.cost, h.nextDate]);
        });
      }
      if (Array.isArray(data.productionLogs)) {
        var shP2 = getOrCreateSheet(ss, "ProductionLogs", ["ID", "Date", "AnimalTag", "Milk_Liters", "MilkIncome_BDT", "FeedCost_BDT", "FeedNote"]);
        clearDataKeepHeader(shP2);
        data.productionLogs.forEach(function(p) {
          shP2.appendRow([p.id, p.date, p.animalTag, p.milk, p.milkIncome, p.feedCost, p.feedNote]);
        });
      }
      if (Array.isArray(data.financeLogs)) {
        var shF2 = getOrCreateSheet(ss, "FinanceLogs", ["ID", "Date", "Type", "Category", "Amount_BDT"]);
        clearDataKeepHeader(shF2);
        data.financeLogs.forEach(function(f) {
          shF2.appendRow([f.id, f.date, f.type, f.category, f.amount]);
        });
      }
      return jsonResponse({ status: "ok", message: "Full sync complete" });
    }

    return jsonResponse({ status: "ignored", action: action });
  } catch (err) {
    return jsonResponse({ status: "error", message: err.message });
  }
}

function getOrCreateSheet(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
  } else if (sh.getLastRow() === 0) {
    sh.appendRow(headers);
  }
  return sh;
}

function clearDataKeepHeader(sh) {
  var lastRow = sh.getLastRow();
  if (lastRow > 1) {
    sh.deleteRows(2, lastRow - 1);
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
